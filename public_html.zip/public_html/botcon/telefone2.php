<?php

error_reporting(0);
set_time_limit(0);

date_default_timezone_set('America/Recife');
$dt_atual = date("Y/m/d H:i:s");
$timestamp_dt_atual = strtotime($dt_atual);

$array_usuarios = file("botcon/usuarios.txt");
$total_usuarios_registrados = count($array_usuarios);

$array_grupos = file("botcon/grupos.txt");
$total_grupos_registrados = count($array_grupos);

$continuar = false;
for($i=0;$i<count($array_usuarios);$i++){
    $explode = explode("|" , $array_usuarios[$i]);
     if($user_id == $explode[0]){
         $vencimento = $explode[1];
         $continuar = true;
     }
}

$timestamp_dt_expira = strtotime($vencimento);

if(!$continuar){
$continuar2 = false;
for($i=0;$i<count($array_grupos);$i++){
    $grupo_vip = explode("|" , $array_grupos[$i]);
     if($chat_id == "-$grupo_vip[0]"){
         $vencimento2 = $grupo_vip[1];
         $continuar2 = true;
     }
}

$timestamp_dt_expira2 = strtotime($vencimento2);
}

if(!$continuar && !$continuar2){
    apiRequest("sendMessage", array('chat_id' => $chat_id, "parse_mode" => "Markdown", "text" => "*Ops, você não tem acesso liberado para utilizar essa consulta?*", "reply_to_message_id" => $message_id, 'reply_markup' => array('inline_keyboard' => array(
                                                      //linha 1
                                                     array(
                                                         array('text'=>'Comprar meu acesso VIP','url'=>'https://t.me/SobraNegra')//botão 1
                                                      )
                                            )
                                    )));

} else if($timestamp_dt_atual < $timestamp_dt_expira || $timestamp_dt_atual < $timestamp_dt_expira2){ 

$comando = str_replace(".", "", $comando);
$comando = str_replace("-", "", $comando);
$tel = $comando;
        
if(is_numeric($tel) === false || strlen($tel) < 9 || strlen($tel) > 11) {

apiRequest("sendMessage", array('chat_id' => $chat_id, "parse_mode" => "Markdown", "text" => "*⚠️ TELEFONE INVÁLIDO!*", "reply_to_message_id" => $message_id, 'reply_markup' => array('inline_keyboard' => array(
                                                      //linha 1
                                                     array(
                                                         array('text'=>'🚮  Apagar  🚮',"callback_data"=>serialize(['id'=>$user_id, 'data'=>'apagar']))
                                                      )
                                            )
                                    )));

}else{
  
function getStr($string, $start, $end) {
	$str = explode($start, $string);
	$str = explode($end, $str[1]);
	return $str[0];
}

sleep(3);
  
$curl = curl_init();

curl_setopt_array($curl, array(
	CURLOPT_URL => "http://vendoapi.host/vendoapi/vendas/shifttelefone.php?info=$tel",
	CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => "",
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 15,
    CURLOPT_FOLLOWLOCATION => true, 
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
	CURLOPT_CUSTOMREQUEST => "GET"
));

$exe = curl_exec($curl);

curl_close($curl);


$n = 0;

$pesquisa = explode('Pesquisar', $exe);
for ($i=1; $i < 21; $i++) { 

    $cpf = getStr($pesquisa[$i], 'data-"','"');
    
    $dados = explode('<span "form-control-static" "formGroupExampleInput5">', $pesquisa[$i]);

    $nome = explode('</span>', $dados[1])[0];

    $divideNome = explode(' ', $nome);

    if(is_numeric($divideNome[8]) === true){
	    $nome = "$divideNome[0] $divideNome[1] $divideNome[2] $divideNome[3] $divideNome[4] $divideNome[5] $divideNome[6] $divideNome[7]";        
    }else if(is_numeric($divideNome[7]) === true){
	    $nome = "$divideNome[0] $divideNome[1] $divideNome[2] $divideNome[3] $divideNome[4] $divideNome[5] $divideNome[6]";
    }else if(is_numeric($divideNome[6]) === true){
	    $nome = "$divideNome[0] $divideNome[1] $divideNome[2] $divideNome[3] $divideNome[4] $divideNome[5]";
    }else if(is_numeric($divideNome[5]) === true){
	    $nome = "$divideNome[0] $divideNome[1] $divideNome[2] $divideNome[3] $divideNome[4]";
    }else if(is_numeric($divideNome[4]) === true){
	    $nome = "$divideNome[0] $divideNome[1] $divideNome[2] $divideNome[3]";
    }else if(is_numeric($divideNome[3]) === true){
	    $nome = "$divideNome[0] $divideNome[1] $divideNome[2]";
    }else if(is_numeric($divideNome[2]) === true){
	    $nome = "$divideNome[0] $divideNome[1]";
    }

    $idade = explode('</span>', $dados[2])[0];     
    $nascimento = explode('</span>', $dados[3])[0];
    $nascimento = explode(' ', $nascimento)[0]; 
    $cidade = explode('</span>', $dados[4])[0];    
    $UF = explode('</span>', $dados[5])[0];
    
    if($idade == '' || $idade == "N&#xE3;o Encontrado") {
        $idade = 'SEM INFORMAÇÃO';
    }
    if($nascimento == '' || $nascimento == "N&#xE3;o Encontrado") {
        $nascimento = 'SEM INFORMAÇÃO';
    }    
    if($cidade == '' || $cidade == "N&#xE3;o Encontrado") {
        $cidade = 'SEM INFORMAÇÃO';
    }    
    if($UF == '' || $UF == "N&#xE3;o Encontrado") {
        $UF = 'SEM INFORMAÇÃO';
    }

    if($cpf == "") break;

    $dados = "*• CPF/CNPJ:* `".$cpf."`\n*• Nome* ".$nome."\n*• Idade:* ".$idade."\n*• Nascimento/Abertura:* ".$nascimento."\n*• Cidade:* ".$cidade."\n*• UF:* ".$UF."\n";
    
    $titulos = $titulos."\n".$dados;

    $n++;
 
}
    
If($titulos != ""){

apiRequest("sendMessage", array('chat_id' => $chat_id, "parse_mode" => "Markdown", "text" => "*══════════════════════
🔍  CONSULTA VIP REALIZADA  🔍
══════════════════════*

*• USUÁRIO:* $first_name

*• Resultado ($n encontrados)*
$titulos
*• BY:* @MkConsultasbot", "reply_to_message_id" => $message_id, 'reply_markup' => array('inline_keyboard' => array(
                                                      //linha 1
                                                     array(
                                                         array('text'=>'🚮  Apagar  🚮',"callback_data"=>serialize(['id'=>$user_id, 'data'=>'apagar']))//botão com callback                                                   
                                                      )
                                            )
                                    )));

}else{ apiRequest("sendMessage", array('chat_id' => $chat_id, "parse_mode" => "Markdown", "text" => "*⚠️ TELEFONE NÃO ENCONTRADO!*", "reply_to_message_id" => $message_id, 'reply_markup' => array('inline_keyboard' => array(                                                                                                                                                    
                                                      //linha 1
                                                     array(
                                                         array('text'=>'🚮  Apagar  🚮',"callback_data"=>serialize(['id'=>$user_id, 'data'=>'apagar']))
                                                      )
                                            )
                                    )));

}}} else { apiRequest("sendMessage", array('chat_id' => $chat_id, "text" => "*Ops, seu acesso venceu entrar em contato com o suporte?*", "reply_to_message_id" => $message_id, 'reply_markup' => array('inline_keyboard' => array(
                                                      //linha 1
                                                     array(
                                                         array('text'=>'Suporte','url'=>'https://t.me/SobraNegra')//botão 1
                                                      )
                                            )
                                    )));

}

?>