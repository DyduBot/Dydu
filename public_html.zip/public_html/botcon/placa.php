<?php

set_time_limit(0);
error_reporting(0);

date_default_timezone_set('America/Recife');
$dt_atual = date("Y/m/d H:i:s");
$timestamp_dt_atual = strtotime($dt_atual);

$array_usuarios = file("botcon/usuarios.txt");
$total_usuarios_registrados = count($array_usuarios);

$array_grupos = file("botcon/grupos.txt");
$total_grupos_registrados = count($array_grupos);

$continuar = false;
for($i=0;$i<count($array_usuarios);$i++){
    $explode = explode("|" , $array_usuarios[$i]);
     if($user_id == $explode[0]){
         $vencimento = $explode[1];
         $continuar = true;
     }
}

$timestamp_dt_expira = strtotime($vencimento);

if(!$continuar){
$continuar2 = false;
for($i=0;$i<count($array_grupos);$i++){
    $grupo_vip = explode("|" , $array_grupos[$i]);
     if($chat_id == "-$grupo_vip[0]"){
         $vencimento2 = $grupo_vip[1];
         $continuar2 = true;
     }
}

$timestamp_dt_expira2 = strtotime($vencimento2);
}

if(!$continuar && !$continuar2){
   apiRequest("sendMessage", array('chat_id' => $chat_id, "parse_mode" => "Markdown", "text" => "*𝗢𝗽𝘀, 𝘃𝗼𝗰𝗲 𝗻𝗮𝗼 𝘁𝗲𝗺 𝗮𝗰𝗲𝘀𝘀𝗼 𝗹𝗶𝗯𝗲𝗿𝗮𝗱𝗼 𝗽𝗮𝗿𝗮 𝘂𝘁𝗶𝗹𝗶𝘇𝗮𝗿 𝗲𝘀𝘀𝗮 𝗰𝗼𝗻𝘀𝘂𝗹𝘁𝗮?*", "reply_to_message_id" => $message_id, 'reply_markup' => array('inline_keyboard' => array(
                                                      //linha 1
                                                     array(
                                                         array('text'=>'Comprar meu acesso VIP',"callback_data"=>'QueroSerVip'), //botão 1
                                                      )
                                            )
                                    )));

} else if($timestamp_dt_atual < $timestamp_dt_expira || $timestamp_dt_atual < $timestamp_dt_expira2){
	
function getStr($string, $start, $end) {
	$str = explode($start, $string);
	$str = explode($end, $str[1]);
	return $str[0];
}
	
$l1 = substr($comando,0,1); 
$l2 = substr($comando,1,1);
$l3 = substr($comando,2,1);

$n1 = substr($comando,3,1); 
$n3 = substr($comando,5,1);
$n4 = substr($comando,6,1);

if(strlen($comando) == 7 && is_numeric($l1) == false && is_numeric($l2) == false && is_numeric($l3) == false && is_numeric($n1) == true && is_numeric($n3) == true && is_numeric($n4) == true) {
	
$placa = $comando;
	
sleep(2);
	
$curl = curl_init();

curl_setopt_array($curl, array(
	CURLOPT_URL => "https://gonzales.tech/MaikinBr_SLHO/placa.php?placa=$placa",
	CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_SSL_VERIFYPEER => false, 
    CURLOPT_SSL_VERIFYHOST => false,
	CURLOPT_TIMEOUT => 10,
	CURLOPT_CUSTOMREQUEST => "GET"
));

$exe = curl_exec($curl);

curl_close($curl);

$exe = str_replace("\u00e1", "á", $exe);
$exe = str_replace("\u00e0", "à", $exe);
$exe = str_replace("\u00e2", "â", $exe);
$exe = str_replace("\u00e3", "ã", $exe);
$exe = str_replace("\u00e9", "é", $exe);
$exe = str_replace("\u00e8", "è", $exe);
$exe = str_replace("\u00ea", "ê", $exe);
$exe = str_replace("\u00ed", "í", $exe);
$exe = str_replace("\u00f3", "ó", $exe);
$exe = str_replace("\u00f2", "ò", $exe);
$exe = str_replace("\u00f4", "ô", $exe);
$exe = str_replace("\u00f5", "õ", $exe);
$exe = str_replace("\u00fa", "ú", $exe);
$exe = str_replace("\u00f9", "ù", $exe);
$exe = str_replace("\u00e7", "ç", $exe);
                      
$situacao = getStr($exe,'"situacao": "','"');
$modelo = getStr($exe,'"modelo": "','"');
$cor = strtoupper(getStr($exe,'"cor": "','"'));
$ano = getStr($exe,'"ano": "','"');
$anoModelo = getStr($exe,'"anoModelo": "','"');
$municipio = getStr($exe,'"municipio": "','"');
$uf = getStr($exe,'"uf": "','"');

$extra = getStr($exe,'"extra": {','"municipio": {');
$chassi = getStr($extra,'"chassi": "','"');
$faturado = getStr($extra,'"faturado": "','"');
$ano_fabricacao = getStr($extra,'"ano_fabricacao": "','"');

$localFabricacao = getStr($exe,'"municipio": {','}');
$municipio_fabricacao = getStr($localFabricacao,'"municipio": "','"');
$uf_fabricacao = getStr($localFabricacao,'"uf": "','"');
$uf_placa = getStr($exe,'"uf_placa": "','"');

$marca_modelo = getStr($exe,'"marca_modelo": {','}');
$marca = getStr($marca_modelo,'"marca": "','"');            
$segmento = strtoupper(getStr($marca_modelo,'"segmento": "','"'));            
$sub_segmento = getStr($marca_modelo,'"sub_segmento": "','"');
$grupoV = getStr($marca_modelo,'"grupo": "','"');            
$version = getStr($marca_modelo,'"version": "','"');            

$combustivel = strtoupper(getStr($exe,'"combustivel": "','"'));
$potencia = getStr($exe,'"potencia": "','"');            
$capacidade_carga = getStr($exe,'"capacidade_carga": "','"');
$nacionalidade = strtoupper(getStr($exe,'"nacionalidade": "','"'));
$linha = getStr($exe,'"linha": "','"');            

$carroceria = getStr($exe,'"carroceria": "','"');
$caixa_cambio = getStr($exe,'"caixa_cambio": "','"');
$eixo_traseiro_dif = getStr($exe,'"eixo_traseiro_dif": "','"');            
$terceiro_eixo = getStr($exe,'"terceiro_eixo": "','"');
$motor = getStr($exe,'"motor": "','"');            
$tipo_pessoa = strtoupper(getStr($exe,'"tipo_pessoa": "','"'));
$uf_faturado = getStr($exe,'"uf_faturado": "','"');
$ano_modelo = getStr($exe,'"ano_modelo": "','"');
$tipo_veiculo = strtoupper(getStr($exe,'"tipo_veiculo": "','"'));
$quantidade_passageiro = getStr($exe,'"quantidade_passageiro": "','"');
$ident_importadora = getStr($exe,'"ident_importadora": "','"');            
$di = getStr($exe,'"di": "','"');
$registro_di = getStr($exe,'"registro_di": "','"');            
$unidade_local_srf = getStr($exe,'"unidade_local_srf": "','"');
$ultima_atualizacao = getStr($exe,'"ultima_atualizacao": "','"');
$cilindradas = getStr($exe,'"cilindradas": "','"');
$situacao_veiculo = getStr($exe,'"situacao_veiculo": "','"');
$placa_modelo_antigo = getStr($exe,'"placa_modelo_antigo": "','"');            
$placa_modelo_novo = getStr($exe,'"placa_modelo_novo": "','"');
                 
                         
If($marca != ""){
	
	$ultima_atualizacao = explode(' ', $ultima_atualizacao)[0];
	$separa = explode('-', $ultima_atualizacao);
	$ultima_atualizacao = "$separa[2]-$separa[1]-$separa[0]";
	
    if($ultima_atualizacao == '--') {
        $ultima_atualizacao = 'SEM INFORMAÇÃO';                   
    }
    if(!$ano) {
        $ano = $ano_fabricacao;                   
    }
    if(!$anoModelo) {
        $anoModelo = $ano_modelo;                   
    }
    if(!$version) {
        $version = 'SEM INFORMAÇÃO';                   
    }
    if(!$carroceria) {
        $carroceria = 'SEM INFORMAÇÃO';                   
    }
    if(!$caixa_cambio) {
        $caixa_cambio = 'SEM INFORMAÇÃO';                   
    }
    if(!$eixo_traseiro_dif) {
        $eixo_traseiro_dif = 'SEM INFORMAÇÃO';                   
    }
    if(!$carroceria) {
        $carroceria = 'SEM INFORMAÇÃO';                   
    }
    if(!$ident_importadora) {
        $ident_importadora = 'SEM INFORMAÇÃO';                   
    }
    if(!$registro_di) {
        $registro_di = 'SEM INFORMAÇÃO';                   
    }

apiRequest("sendMessage", array('chat_id' => $chat_id, "parse_mode" => "Markdown", "text" => "*══════════════════════
🔍 𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 𝗥𝗘𝗔𝗟𝗜𝗭𝗔𝗗𝗔 🔍
══════════════════════

• 𝗢𝗹𝗮 𝗨𝗦𝗨𝗔𝗥𝗜𝗢:* [$first_name]

*• PLACA:* `$placa`
*• UF - PLACA:* `$uf_placa`
*• SITUAÇÃO:* `$situacao`

*• MARCA:* `$marca`
*• MODELO:* `$modelo`
*• COR:* `$cor`

*• ANO - FABRICAÇÃO:* `$ano`
*• ANO - MODELO:* `$anoModelo`

*• CIDADE:* `$municipio`
*• ESTADO:* `$uf`

*• CHASSI:* `$chassi`
*• FATURADO:* `$faturado`
*• UF - FATURADO:* `$uf_faturado`

*• CIDADE - FABRICAÇÃO:* `$municipio_fabricacao`
*• ESTADO - FABRICAÇÃO:* `$uf_fabricacao`

*• SEGMENTO:* `$segmento`
*• SUB SEGMENTO:* `$sub_segmento`
*• GRUPO:* `$grupoV`
*• VERSÃO:* `$version`

*• COMBUSTIVEL:* `$combustivel`
*• POTENCIA:* `$potencia`
*• CAPACIDADE DE CARGA:* `$capacidade_carga`
*• NACIONALIDADE:* `$nacionalidade`
*• LINHA:* `$linha`

*• CARROCERIA:* `$carroceria`
*• CAIXA DE CAMBIO:* `$caixa_cambio`
*• EIXO TRASEIRO:* `$eixo_traseiro_dif`
*• MOTOR:* `$motor`

*• TIPO DE PESSOA:* `$tipo_pessoa`
*• TIPO DE VEICULO:* `$tipo_veiculo`
*• QUANTIDADE DE PASSAGEIROS:* `$quantidade_passageiro`

*• IDENTIDADE IMPORTADORA:* `$ident_importadora`
*• DI:* `$di`
*• REGISTRO DI:* `$registro_di`
*• UNIDADE LOCAL SRF:* `$unidade_local_srf`

*• ULTIMA ATUALIZAÇÃO:* `$ultima_atualizacao`

*• CILINDRADAS:* `$cilindradas`

*• SITUAÇÃO DO VEICULO:* `$situacao_veiculo`

*• PLACA MODELO ANTIGO:* `$placa_modelo_antigo`
*• PLACA MODELO NOVO:* `$placa_modelo_novo`

*• BY:* @MkConsultasbot", "reply_to_message_id" => $message_id,'reply_markup' => array('inline_keyboard' => array(
                                                      //linha 1
                                                     array(
                                                         array('text'=>'🚮  Apagar  🚮',"callback_data"=>serialize(['id'=>$user_id, 'data'=>'apagar']))//botão com callback                                                   
                                                      )
                                            )
                                    )));

}else{ apiRequest("sendMessage", array('chat_id' => $chat_id, "parse_mode" => "Markdown", "text" => "*⚠️ PLACA NÃO ENCONTRADA!*", "reply_to_message_id" => $message_id,'reply_markup' => array('inline_keyboard' => array(
                                                      //linha 1
                                                     array(
                                                         array('text'=>'🚮  Apagar  🚮',"callback_data"=>serialize(['id'=>$user_id, 'data'=>'apagar']))//botão com callback                                                   
                                                      )
                                            )
                                    )));

if($type != 'private') {
    sleep(10);
    $posterior = $message_id - 1;
    apiRequest("deleteMessage", array('chat_id' => $chat_id, 'message_id' => $message_id));
    apiRequest("deleteMessage", array('chat_id' => $chat_id, 'message_id' => $posterior));
}

}}else{ apiRequest("sendMessage", array('chat_id' => $chat_id, "parse_mode" => "Markdown", "text" => "*⚠️ PLACA INVÁLIDA!*", "reply_to_message_id" => $message_id,'reply_markup' => array('inline_keyboard' => array(                                                                            
                                                      //linha 1
                                                     array(
                                                         array('text'=>'🚮  Apagar  🚮',"callback_data"=>serialize(['id'=>$user_id, 'data'=>'apagar']))//botão com callback                                                   
                                                      )
                                            )
                                    ))); 

if($type != 'private') {
    sleep(10);
    $posterior = $message_id - 1;
    apiRequest("deleteMessage", array('chat_id' => $chat_id, 'message_id' => $message_id));
    apiRequest("deleteMessage", array('chat_id' => $chat_id, 'message_id' => $posterior));
}

}} else { apiRequest("sendMessage", array('chat_id' => $chat_id, "text" => "*𝗢𝗽𝘀, 𝘀𝗲𝘂 𝗮𝗰𝗲𝘀𝘀𝗼 𝘃𝗲𝗻𝗰𝗲𝘂 𝗲𝗻𝘁𝗿𝗮𝗿 𝗲𝗺 𝗰𝗼𝗻𝘁𝗮𝘁𝗼 𝗰𝗼𝗺 𝗼 𝘀𝘂𝗽𝗼𝗿𝘁𝗲?*", "reply_to_message_id" => $message_id, 'reply_markup' => array('inline_keyboard' => array(
                                                      //linha 1
                                                     array(
                                                         array('text'=>'Comprar meu acesso VIP',"callback_data"=>'QueroSerVip'), //botão 1
                                                      )
                                            )
                                    )));

}

?>