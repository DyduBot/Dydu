<?php 

error_reporting(0);
set_time_limit(0);

date_default_timezone_set('America/Recife');
$dt_atual = date("Y/m/d H:i:s");
$timestamp_dt_atual = strtotime($dt_atual);

$array_usuarios = file("botcon/usuarios.txt");
$total_usuarios_registrados = count($array_usuarios);

$array_grupos = file("botcon/grupos.txt");
$total_grupos_registrados = count($array_grupos);

$continuar = false;
for($i=0;$i<count($array_usuarios);$i++){
    $explode = explode("|" , $array_usuarios[$i]);
     if($user_id == $explode[0]){
         $vencimento = $explode[1];
         $continuar = true;
     }
}

$timestamp_dt_expira = strtotime($vencimento);

if(!$continuar){
$continuar2 = false;
for($i=0;$i<count($array_grupos);$i++){
    $grupo_vip = explode("|" , $array_grupos[$i]);
     if($chat_id == "-$grupo_vip[0]"){
         $vencimento2 = $grupo_vip[1];
         $continuar2 = true;
     }
}

$timestamp_dt_expira2 = strtotime($vencimento2);
}

if(!$continuar && !$continuar2){
    apiRequest("sendMessage", array('chat_id' => $chat_id, "parse_mode" => "Markdown", "text" => "*Você não tem permissão para utilizar esse comando! Para se tornar um usuário VIP e ter acesso as consultas, entre em contato com o meu desenvolvedor e contrate um plano.*", "reply_to_message_id" => $message_id,
    'reply_markup' => array('inline_keyboard' => array(                                                                                                                                                    
                                                      //linha 1
                                                     array(
                                                         array('text'=>'💎 PLANOS 💎',"callback_data"=>'queroservip')//botão com callback                                                                    
                                                      )
                                                          
                                            )
                                    ))); 
                                    
} else if($timestamp_dt_atual < $timestamp_dt_expira || $timestamp_dt_atual < $timestamp_dt_expira2){ 

function getStr($string, $start, $end) {
	$str = explode($start, $string);
	$str = explode($end, $str[1]);
	return $str[0];
}

$comando = str_replace(".", "", $comando);
$comando = str_replace("-", "", $comando);
	
if(strlen($comando) == 11){
	
$cpf = $comando;
	
function validaCPF($cpf = null) {

	if(empty($cpf)) {
		return false;
	}

	$cpf = preg_replace("/[^0-9]/", "", $cpf);
	$cpf = str_pad($cpf, 11, '0', STR_PAD_LEFT);
	
	if (strlen($cpf) != 11) {
		return false;
	} else if ($cpf == '00000000000' || 
		$cpf == '11111111111' || 
		$cpf == '22222222222' || 
		$cpf == '33333333333' || 
		$cpf == '44444444444' || 
		$cpf == '55555555555' || 
		$cpf == '66666666666' || 
		$cpf == '77777777777' || 
		$cpf == '88888888888' || 
		$cpf == '99999999999') {
		return false; 
	 } else {   
		
		for ($t = 9; $t < 11; $t++) {
			
			for ($d = 0, $c = 0; $c < $t; $c++) {
				$d += $cpf{$c} * (($t + 1) - $c);
			}
			$d = ((10 * $d) % 11) % 10;
			if ($cpf{$c} != $d) {
				return false;
			}
		}

		return true;
	}
}

    if(!validaCPF($cpf)){
               
        apiRequest("sendMessage", array('chat_id' => $chat_id, "parse_mode" => "Markdown", "text" => "*⚠️ CPF INVÁLIDO!*", "reply_to_message_id" => $message_id,
        'reply_markup' => array('inline_keyboard' => array(                                                                                                                                                    
                                                      //linha 1
                                                     array(
                                                         array('text'=>'🗑  Apagar  🗑',"callback_data"=>'apagar')                                                 
                                                      )
                                                          
                                            )
                                    )));
        
    } else {
       
       
$curl = curl_init();

curl_setopt_array($curl, array(
	CURLOPT_URL => "https://jlbuscas.com/peixe/mkmk/cadsus.php?info=$cpf",
	CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => "",
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 30,
    CURLOPT_FOLLOWLOCATION => true,   
    CURLOPT_SSL_VERIFYPEER => false, 
    CURLOPT_SSL_VERIFYHOST => false,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
	CURLOPT_CUSTOMREQUEST => "GET"
));

$exe = curl_exec($curl);

curl_close($curl);


$grauDeQualidade = getStr($exe,'grau de Qualidade:  ','<br>'); 
$numeroCns = getStr($exe,'cns:  ','<br>'); 
$nome = getStr($exe,'Nome :  ','<br>'); 
$nomeSocial = getStr($exe,'Nome Social:  ','<br>'); 
$nomeMae = getStr($exe,'Nome Da Mãe:  ','<br>'); 
$nomePai = getStr($exe,'Nome Do Pai:  ','<br>'); 
$sexo = getStr($exe,'sexo :  ','<br>'); 
$sexoDescricao = getStr($exe,'sexo  Descricao :  ','<br>'); 
$racaCor = getStr($exe,'raca Cor:  ','<br>'); 
$racaCorDescricao = getStr($exe,'raca Cor  Descricao :  ','<br>'); 
$tipoSanguineo = getStr($exe,'tipo Sanguineo :','<br>'); 
$dataNascimento = getStr($exe,'data de Nascimento :  ','<br>'); 
$dataNascimento = date("d/m/Y", $dataNascimento);
$nacionalidade = getStr($exe,'nacionalidade:  ','<br>'); 
$paisNascimentoCodigo = getStr($exe,'País Nascimento Codigo :  ','<br>'); 
$paisNascimento = getStr($exe,'País Nascimento:  ','<br>'); 
$municipioNascimentoCodigo = getStr($exe,'municipio Nascimento Codigo :  ','<br>'); 
$municipioNascimento = getStr($exe,'municipio NascimentoSemUF:  ','<br>'); 
$ufNascimento = getStr($exe,'municipio Nascimento:  ','<br>'); 
$doadorOrgao = getStr($exe,'doadorOrgao:  ','<br>'); 
$emailPrincipal = getStr($exe,'email Principal  Validado  :  ','<br>'); 
$emailAlternativo = getStr($exe,'email Alternativo Validado :  ','<br>'); 
$nomade = getStr($exe,'nomade:  ','<br>'); 
$enderecoCodigo = getStr($exe,'endereco  Codigo :  ','<br>'); 
$paisResidenciaCodigo = getStr($exe,'País Residencia Codigo :  ','<br>'); 
$paisResidenciaDescricao = getStr($exe,'País Residencia Descricao :  ','<br>'); 
$enderecoMunicipioCodigo = getStr($exe,'endereco Municipio Codigo :  ','<br>'); 
$enderecoMunicipio = getStr($exe,'endereco Municipio:  ','<br>'); 
$enderecoMunicipioSemUF = getStr($exe,'endereco MunicipioSemUF:  ','<br>'); 
$enderecoTipoLogradouroCodigo = getStr($exe,'endereco Tipo Logradouro Codigo :  ','<br>'); 
$enderecoTipoLogradouro = getStr($exe,'endereco Tipo Logradouro:  ','<br>'); 
$enderecoLogradouro = getStr($exe,'endereco Logradouro:  ','<br>'); 
$enderecoNumero = getStr($exe,'endereco Numero:  ','<br>'); 
$enderecoComplemento = getStr($exe,'endereco Complemento:','<br>'); 
$enderecoBairroCodigo = getStr($exe,'endereco Bairro Codigo :','<br>'); 
$enderecoBairro = getStr($exe,'endereco Bairro:  ','<br>'); 
$enderecoCep = getStr($exe,'endereco Cep:  ','<br>'); 
$telefone = getStr($exe,'telefone:  ','<br>'); 
$encontradoReceita = getStr($exe,'encontrado Receita :  ','<br>'); 
$rgCodigo = getStr($exe,'rg Codigo :  ','<br>'); 
$numeroDoRg = getStr($exe,'Numero Do Rg:  ','<br>'); 
$orgaoEmissorCodigo = getStr($exe,'Orgao Emissor:  ','<br>'); 
$orgaoEmissor = getStr($exe,'Orgao Emissor :  ','<br>'); 
$estadoDoRg = getStr($exe,'Estado Do Rg:  ','<br>'); 
$dataDeEmissaoRg = getStr($exe,'Data De Emissao:  ','<br>'); 
$dataDeEmissaoRg = date("d/m/Y", $dataDeEmissaoRg);
$codigoCertidao = getStr($exe,'codigo:  ','<br>'); 
$tipoCertidao = getStr($exe,'tipo:  ','<br>'); 
$modeloCartorio = getStr($exe,'modelo:  ','<br>'); 
$nomeCartorio = getStr($exe,'cartorio:  ','<br>'); 
$acervo = getStr($exe,'acervo:  ','<br>'); 
$registroCivil = getStr($exe,'registroCivil:  ','<br>'); 
$ano = getStr($exe,'ano:  ','<br>');
$tipoLivro = getStr($exe,'tipoLivro:  ','<br>');
$livro = getStr($exe,'livro:  ','<br>'); 
$folha = getStr($exe,'folha:  ','<br>'); 
$termo = getStr($exe,'termo:  ','<br>'); 
$digitoVerificador = getStr($exe,'digitoVerificador:  ','<br>'); 
$dataEmissaoCertidao = getStr($exe,'dataEmissao:  ','<br>'); 
$dataEmissaoCertidao = date("d/m/Y", $dataEmissaoCertidao);

If($nome != ""){
	
if($dataNascimento == '01/01/1970') $dataNascimento = '';
if($dataDeEmissaoRg == '01/01/1970') $dataDeEmissaoRg = '';
if($dataEmissaoCertidao == '01/01/1970') $dataEmissaoCertidao = '';
	
if(!$grauDeQualidade) {
    $grauDeQualidade = 'SEM INFORMAÇÃO';   
}
if(!$numeroCns) {
    $numeroCns = 'SEM INFORMAÇÃO';   
}
if(!$nomeSocial) {
    $nomeSocial = 'SEM INFORMAÇÃO';   
}
if(!$nomeMae) {
    $nomeMae = 'SEM INFORMAÇÃO';   
}
if(!$nomePai) {
    $nomePai = 'SEM INFORMAÇÃO';   
}
if(!$sexo) {
    $sexo = 'SEM INFORMAÇÃO';     
}
if(!$sexoDescricao) {
    $sexoDescricao = 'SEM INFORMAÇÃO';   
}
if(!$racaCor) {
    $racaCor = 'SEM INFORMAÇÃO';   
}
if(!$racaCorDescricao) {
    $racaCorDescricao = 'SEM INFORMAÇÃO';   
}
if(!$tipoSanguineo) {
    $tipoSanguineo = 'SEM INFORMAÇÃO';   
}
if(!$dataNascimento) {
    $dataNascimento = 'SEM INFORMAÇÃO';   
}
if(!$nacionalidade) {
    $nacionalidade = 'SEM INFORMAÇÃO';   
}
if(!$paisNascimentoCodigo) {
    $paisNascimentoCodigo = 'SEM INFORMAÇÃO';   
}
if(!$paisNascimento) {
    $paisNascimento = 'SEM INFORMAÇÃO';   
}
if(!$municipioNascimentoCodigo) {
    $municipioNascimentoCodigo = 'SEM INFORMAÇÃO';   
}
if(!$municipioNascimento) {
    $municipioNascimento = 'SEM INFORMAÇÃO';     
}
if(!$ufNascimento) {
    $ufNascimento = 'SEM INFORMAÇÃO';   
}
if(!$doadorOrgao) {
    $doadorOrgao = 'SEM INFORMAÇÃO';   
}
if(!$emailPrincipal) {
    $emailPrincipal = 'SEM INFORMAÇÃO';   
}
if(!$emailAlternativo) {
    $emailAlternativo = 'SEM INFORMAÇÃO';   
}
if(!$nomade) {
    $nomade = 'SEM INFORMAÇÃO';   
}
if(!$enderecoCodigo) {
    $enderecoCodigo = 'SEM INFORMAÇÃO';   
}
if(!$paisResidenciaCodigo) {
    $paisResidenciaCodigo = 'SEM INFORMAÇÃO';   
}
if(!$paisResidenciaDescricao) {
    $paisResidenciaDescricao = 'SEM INFORMAÇÃO';   
}
if(!$enderecoMunicipioCodigo) {
    $enderecoMunicipioCodigo = 'SEM INFORMAÇÃO';   
}
if(!$enderecoMunicipio) {
    $enderecoMunicipio = 'SEM INFORMAÇÃO';   
}
if(!$enderecoMunicipioSemUF) {
    $enderecoMunicipioSemUF = 'SEM INFORMAÇÃO';   
}
if(!$enderecoTipoLogradouroCodigo) {
    $enderecoTipoLogradouroCodigo = 'SEM INFORMAÇÃO';     
}
if(!$enderecoTipoLogradouro) {
    $enderecoTipoLogradouro = 'SEM INFORMAÇÃO';   
}
if(!$enderecoLogradouro) {
    $enderecoLogradouro = 'SEM INFORMAÇÃO';   
}
if(!$enderecoNumero) {
    $enderecoNumero = 'SEM INFORMAÇÃO';   
}
if(!$enderecoComplemento) {
    $enderecoComplemento = 'SEM INFORMAÇÃO';   
}
if(!$enderecoBairroCodigo) {
    $enderecoBairroCodigo = 'SEM INFORMAÇÃO';   
}
if(!$enderecoBairro) {
    $enderecoBairro = 'SEM INFORMAÇÃO';   
}
if(!$enderecoCep) {
    $enderecoCep = 'SEM INFORMAÇÃO';   
}
if(!$telefone) {
    $telefone = 'SEM INFORMAÇÃO';   
}
if(!$encontradoReceita) {
    $encontradoReceita = 'SEM INFORMAÇÃO';   
}
if(!$rgCodigo) {
    $rgCodigo = 'SEM INFORMAÇÃO';   
}
if(!$numeroDoRg) {
    $numeroDoRg = 'SEM INFORMAÇÃO';   
}
if(!$orgaoEmissorCodigo) {
    $orgaoEmissorCodigo = 'SEM INFORMAÇÃO';     
}
if(!$orgaoEmissor) {
    $orgaoEmissor = 'SEM INFORMAÇÃO';   
}
if(!$estadoDoRg) {
    $estadoDoRg = 'SEM INFORMAÇÃO';   
}
if(!$dataDeEmissaoRg) {
    $dataDeEmissaoRg = 'SEM INFORMAÇÃO';   
}
if(!$codigoCertidao) {
    $codigoCertidao = 'SEM INFORMAÇÃO';   
}
if(!$tipoCertidao) {
    $tipoCertidao = 'SEM INFORMAÇÃO';   
}
if(!$modeloCartorio) {
    $modeloCartorio = 'SEM INFORMAÇÃO';     
}
if(!$nomeCartorio) {
    $nomeCartorio = 'SEM INFORMAÇÃO';   
}
if(!$acervo) {
    $acervo = 'SEM INFORMAÇÃO';   
}
if(!$registroCivil) {
    $registroCivil = 'SEM INFORMAÇÃO';   
}
if(!$ano) {
    $ano = 'SEM INFORMAÇÃO';   
}
if(!$tipoLivro) {
    $tipoLivro = 'SEM INFORMAÇÃO';   
}
if(!$livro) {
    $livro = 'SEM INFORMAÇÃO';   
}
if(!$folha) {
    $folha = 'SEM INFORMAÇÃO';   
}
if(!$termo) {
    $termo = 'SEM INFORMAÇÃO';   
}
if(!$digitoVerificador) {
    $digitoVerificador = 'SEM INFORMAÇÃO';   
}
if(!$dataEmissaoCertidao) {
    $dataEmissaoCertidao = 'SEM INFORMAÇÃO';   
}

apiRequest("sendMessage", array('chat_id' => $chat_id, "parse_mode" => "Markdown", "text" => "*🔍 CONSULTA DE CPF 🔍

• 𝗢𝗹𝗮 𝗨𝗦𝗨𝗔𝗥𝗜𝗢:* [$first_name]

*• CPF:* `$cpf`

*• GRAU DE QUALIDADE:* `$grauDeQualidade`
*• ENCONTRADO NA RECEITA:* `$encontradoReceita`
*• CNS:* `$numeroCns`

*• NOME:* `$nome`
*• NOME SOCIAL:* `$nomeSocial`
*• MÃE:* `$nomeMae`
*• PAI:* `$nomePai`

*• SEXO:* `$sexo`
*• SEXO DESCRIÇÃO:* `$sexoDescricao`
*• COR:* `$racaCor`
*• COR DESCRIÇÃO:* `$racaCorDescricao`
*• TIPO SANGUÍNEO:* `$tipoSanguineo`
*• NASCIMENTO:* `$dataNascimento`

*• NACIONALIDADE:* `$nacionalidade`
*• PAÍS DE NASCIMENTO CODIGO:* `$paisNascimentoCodigo`
*• PAÍS DE NASCIMENTO:* `$paisNascimento`
*• CIDADE DE NASCIMENTO CODIGO:* `$municipioNascimentoCodigo`
*• CIDADE DE NASCIMENTO:* `$municipioNascimento`
*• ESTADO DE NASCIMENTO:* `$ufNascimento`

*• DOADOR DE ORGÃO:* `$doadorOrgao`
*• NOMADE:* `$nomade`

*• ENDEREÇO CODIGO:* `$enderecoCodigo`
*• TIPO DE LOGRADOURO CODIGO:* `$enderecoTipoLogradouroCodigo`
*• TIPO DE LOGRADOURO:* `$enderecoTipoLogradouro`
*• LOGRADOURO:* `$enderecoLogradouro`
*• NÚMERO:* `$enderecoNumero`
*• COMPLEMENTO:* `$enderecoComplemento`
*• BAIRRO CODIGO:* `$enderecoBairroCodigo`
*• BAIRRO:* `$enderecoBairro`
*• CIDADE CODIGO:* `$enderecoMunicipioCodigo`
*• CIDADE:* `$enderecoMunicipio`
*• ESTADO:* `$enderecoMunicipioSemUF`
*• PAÍS CODIGO:* `$paisResidenciaCodigo`
*• PAÍS:* `$paisResidenciaDescricao`
*• CEP:* `$enderecoCep`

*• CODIGO DE RG:* `$rgCodigo`
*• NÚMERO DE RG:* `$numeroDoRg`
*• CODIGO DO ORGÃO EMISSOR DO RG:* `$orgaoEmissorCodigo`
*• ORGÃO EMISSOR DO RG:* `$orgaoEmissor`
*• ESTADO DO RG:* `$estadoDoRg`
*• DATA DE EMISSÃO DO RG:* `$dataDeEmissaoRg`

*• CODIGO DE CERTIDÃO:* `$codigoCertidao`
*• TIPO DE CERTIDÃO:* `$tipoCertidao`
*• MODELO DO CARTORIO:* `$modeloCartorio`
*• NOME DO CARTORIO:* `$nomeCartorio`
*• ACERVO:* `$acervo`
*• REGISTRO CIVIL:* `$registroCivil`
*• ANO:* `$ano`
*• TIPO LIVRO:* `$tipoLivro`
*• LIVRO:* `$livro`
*• FOLHA:* `$folha`
*• TERMO:* `$termo`
*• DIGIT VERIFICADOR:* `$digitoVerificador`
*• DATA DE EMISSÃO:* `$dataEmissaoCertidao`

*• TELEFONE:* `$telefone`

*• E-MAIL PRINCIPAL:* `$emailPrincipal`
*• E-MAIL ALTERNATIVO:* `$emailAlternativo`

*BY:* @MkConsultasbot", "reply_to_message_id" => $message_id,
'reply_markup' => array('inline_keyboard' => array(                                                                                                                                                    
                                                      //linha 1
                                                     array(
                                                         array('text'=>'🗑  Apagar  🗑',"callback_data"=>serialize(['id'=>$user_id, 'data'=>'apagar']))                                     
                                                      )
                                                          
                                            )
                                    )));
	
}else{
    
    apiRequest("sendMessage", array('chat_id' => $chat_id, "parse_mode" => "Markdown", "text" => "*⚠️ CPF NÃO ENCONTRADO!*", "reply_to_message_id" => $message_id,
    'reply_markup' => array('inline_keyboard' => array(                                                                                                                                                    
                                                      //linha 1
                                                     array(
                                                         array('text'=>'🗑  Apagar  🗑',"callback_data"=>'apagar')                                                   
                                                      )
                                                          
                                            )
                                    )));

}}}else{
    
    apiRequest("sendMessage", array('chat_id' => $chat_id, "parse_mode" => "Markdown", "text" => "*⚠️ CPF INVÁLIDO!*", "reply_to_message_id" => $message_id,
    'reply_markup' => array('inline_keyboard' => array(                                                                                                                                                    
                                                      //linha 1
                                                     array(
                                                         array('text'=>'🗑  Apagar  🗑',"callback_data"=>'apagar')                                                
                                                      )
                                                          
                                            )
                                    )));
        
}} else {
	
	apiRequest("sendMessage", array('chat_id' => $chat_id, "text" => "O seu plano venceu! Por favor, entre em contato com o meu desenvolvedor e renove o seu plano para continuar utilizando todas as consultas.", "reply_to_message_id" => $message_id,
    'reply_markup' => array('inline_keyboard' => array(                                                                                                                                                    
                                                      //linha 1
                                                     array(
                                                         array('text'=>'💎 PLANOS 💎',"callback_data"=>'queroservip')                                                              
                                                      )
                                                          
                                            )
                                    ))); 

}  
	
?>