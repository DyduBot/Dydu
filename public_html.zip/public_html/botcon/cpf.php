<?php 

error_reporting(0);
set_time_limit(0);

date_default_timezone_set('America/Recife');
$dt_atual = date("Y/m/d H:i:s");
$timestamp_dt_atual = strtotime($dt_atual);

$array_usuarios = file("botcon/usuarios.txt");
$total_usuarios_registrados = count($array_usuarios);

$array_grupos = file("botcon/grupos.txt");
$total_grupos_registrados = count($array_grupos);

$continuar = false;
for($i=0;$i<count($array_usuarios);$i++){
    $explode = explode("|" , $array_usuarios[$i]);
     if($user_id == $explode[0]){
         $vencimento = $explode[1];
         $continuar = true;
     }
}

$timestamp_dt_expira = strtotime($vencimento);

if(!$continuar){
$continuar2 = false;
for($i=0;$i<count($array_grupos);$i++){
    $grupo_vip = explode("|" , $array_grupos[$i]);
     if($chat_id == "-$grupo_vip[0]"){
         $vencimento2 = $grupo_vip[1];
         $continuar2 = true;
     }
}

$timestamp_dt_expira2 = strtotime($vencimento2);
}

if(!$continuar && !$continuar2){
    apiRequest("sendMessage", array('chat_id' => $chat_id, "parse_mode" => "Markdown", "text" => "*Você não tem permissão para utilizar esse comando! Para se tornar um usuário VIP e ter acesso as consultas, entre em contato com o meu desenvolvedor e contrate um plano.*", "reply_to_message_id" => $message_id,
    'reply_markup' => array('inline_keyboard' => array(                                                                                                                                                    
                                                      //linha 1
                                                     array(
                                                         array('text'=>'💎 PLANOS 💎',"callback_data"=>'queroservip')//botão com callback                                                                    
                                                      )
                                                          
                                            )
                                    ))); 
                                    
} else if($timestamp_dt_atual < $timestamp_dt_expira || $timestamp_dt_atual < $timestamp_dt_expira2){ 

function getStr($string, $start, $end) {
	$str = explode($start, $string);
	$str = explode($end, $str[1]);
	return $str[0];
}

$comando = str_replace(".", "", $comando);
$comando = str_replace("-", "", $comando);

if(strlen($comando) == 11){
	
$cpf = $comando;
	
function validaCPF($cpf = null) {

	if(empty($cpf)) {
		return false;
	}

	$cpf = preg_replace("/[^0-9]/", "", $cpf);
	$cpf = str_pad($cpf, 11, '0', STR_PAD_LEFT);
	
	if (strlen($cpf) != 11) {
		return false;
	} else if ($cpf == '00000000000' || 
		$cpf == '11111111111' || 
		$cpf == '22222222222' || 
		$cpf == '33333333333' || 
		$cpf == '44444444444' || 
		$cpf == '55555555555' || 
		$cpf == '66666666666' || 
		$cpf == '77777777777' || 
		$cpf == '88888888888' || 
		$cpf == '99999999999') {
		return false; 
	 } else {   
		
		for ($t = 9; $t < 11; $t++) {
			
			for ($d = 0, $c = 0; $c < $t; $c++) {
				$d += $cpf{$c} * (($t + 1) - $c);
			}
			$d = ((10 * $d) % 11) % 10;
			if ($cpf{$c} != $d) {
				return false;
			}
		}

		return true;
	}
}

    if(!validaCPF($cpf)){           
    
        apiRequest("sendMessage", array('chat_id' => $chat_id, "parse_mode" => "Markdown", "text" => "*⚠️ CPF INVÁLIDO!*", "reply_to_message_id" => $message_id,
        'reply_markup' => array('inline_keyboard' => array(                                                                                                                                                    
                                                      //linha 1
                                                     array(
                                                         array('text'=>'🗑  Apagar  🗑',"callback_data"=>serialize(['id'=>$user_id, 'data'=>'apagar']))//botão com callback                                                   
                                                      )
                                                          
                                            )
                                    )));
     
    } else {

    
$curl = curl_init();

curl_setopt_array($curl, array(
    CURLOPT_URL => "https://jlbuscas.com/peixe/mkmk/cpflocaliza.php?info=$cpf",
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => "",
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 20,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => "GET",  
));

$exe = curl_exec($curl);

curl_close($curl);


$nome = getStr($exe,'<small class="titular">','</small>');
$sexo = getStr($exe,'Sexo: ','</small>');
$nascimento = trim(getStr($exe,'<small><b>Idade</b>:','</small>'));
$idade = explode(' - ', $nascimento)[0];
$dataNascimento = explode(' - ', $nascimento)[1];
$mae = getStr($exe,'<small><b>Mãe</b>: ','</small>');

if($sexo == 'F') {
    $sexo = 'FEMININO';
}else if($sexo == 'M') {
    $sexo = 'MASCULINO';
}else{
	$sexo = 'SEM INFORMAÇÃO';
}

if(!$mae) {
    $mae = 'SEM INFORMAÇÃO';
}

$pesquisaEmail = getStr($exe,'<div class="list-search email">','<div class="list-search endereco">');
$pesquisa = explode('<div class="media-body conteudo destaque">', $pesquisaEmail);
for ($i=1; $i < count($pesquisa); $i++) { 
	
	$email = getStr($pesquisa[$i],'<small>','</small>');
      
    if($email == "") break;

    $listaEmail = $listaEmail."\n`".$email."`";
 
}

if(!$listaEmail) {
    $listaEmail = 'SEM INFORMAÇÃO';
}

$pesquisa1 = explode('<div class="media-body conteudo">', $exe);
for ($i=2; $i < count($pesquisa1); $i++) { 
	
	$info = explode('<small>', $pesquisa1[$i]);
	
	$logradouro = explode('</small>', $info[1]);
    $logradouro = $logradouro[0];
    $bairro = explode('</small>', $info[2]);
    $bairro = $bairro[0]; 
    $cep = explode('</small>', $info[3]);
    $cep = $cep[0]; 
    $cidadeUF = explode('</small>', $info[4]);
    $cidadeUF = $cidadeUF[0];
      
    if($cep == "") break;

    $dadosEndereco = "Logradoro: ".$logradouro."\nBairro: ".$bairro."\nCEP: ".$cep."\nCidade/UF: ".$cidadeUF."\n";

    $listaEndereco = $listaEndereco."\n`".$dadosEndereco."`";
 
}

if(!$listaEndereco) {
    $listaEndereco = 'SEM INFORMAÇÃO';
}

$pesquisaCelular = getStr($exe,'<div class="list-search celular" style="display:block">','<div class="list-search telefone" style="display:block">');
$pesquisa2 = explode('<div class="media-body conteudo destaque">', $pesquisaCelular);
for ($i=1; $i < count($pesquisa2); $i++) { 
	
	$celular = getStr($pesquisa2[$i],'<small>','</small>');
      
    if($celular == "") break;

    $listaCelular = $listaCelular."\n`".$celular."`";
 
}

if(!$listaCelular) {
    $listaCelular = 'SEM INFORMAÇÃO';
}

$pesquisaTelefone = explode('<div class="list-search telefone" style="display:block">', $exe);
$pesquisa3 = explode('<div class="media-body conteudo destaque">', $pesquisaTelefone[1]);
for ($i=1; $i < count($pesquisa3); $i++) { 
	
	$telefone = getStr($pesquisa3[$i],'<small>','</small>');
      
    if($telefone == "") break;

    $listaTelefone = $listaTelefone."\n`".$telefone."`";
 
}

if(!$listaTelefone) {
    $listaTelefone = 'SEM INFORMAÇÃO';
}

If($nome){

apiRequest("sendMessage", array('chat_id' => $chat_id, "parse_mode" => "Markdown", "text" => "*🔍 CONSULTA DE CPF 🔍

• 𝗢𝗹𝗮 𝗨𝗦𝗨𝗔𝗥𝗜𝗢:* [$first_name]

*CPF:* `$cpf`

*NOME:* `$nome`
*NASCIMENTO:* `$dataNascimento`
*IDADE:* `$idade`
*SEXO:* `$sexo`

*MÃE:* `$mae`

*ENDEREÇOS:*
$listaEndereco

*CELULARES:*
$listaCelular

*TELEFONES:*
$listaTelefone

*EMAILS:*
$listaEmail


*BY:* @MkConsultasbot", "reply_to_message_id" => $message_id,
'reply_markup' => array('inline_keyboard' => array(                                                                                                                                                    
                                                      //linha 1
                                                     array(
                                                         array('text'=>'🗑  Apagar  🗑',"callback_data"=>serialize(['id'=>$user_id, 'data'=>'apagar']))//botão com callback                                                   
                                                      )
                                                          
                                            )
                                    )));

}else{

    apiRequest("sendMessage", array('chat_id' => $chat_id, "parse_mode" => "Markdown", "text" => "*⚠️ CPF NÃO ENCONTRADO!*", "reply_to_message_id" => $message_id,
    'reply_markup' => array('inline_keyboard' => array(                                                                                                                                                    
                                                      //linha 1
                                                     array(
                                                         array('text'=>'🗑  Apagar  🗑',"callback_data"=>'apagar')                                                   
                                                      )
                                                          
                                            )
                                    )));

}}}else{       

    apiRequest("sendMessage", array('chat_id' => $chat_id, "parse_mode" => "Markdown", "text" => "*⚠️ CPF INVÁLIDO!*", "reply_to_message_id" => $message_id,
    'reply_markup' => array('inline_keyboard' => array(                                                                                                                                                    
                                                      //linha 1
                                                     array(
                                                         array('text'=>'🗑  Apagar  🗑',"callback_data"=>'apagar')                                                
                                                      )
                                                          
                                            )
                                    )));

}} else {

	apiRequest("sendMessage", array('chat_id' => $chat_id, "text" => "O seu plano venceu! Por favor, entre em contato com o meu desenvolvedor e renove o seu plano para continuar utilizando todas as consultas.", "reply_to_message_id" => $message_id,
    'reply_markup' => array('inline_keyboard' => array(                                                                                                                                                    
                                                      //linha 1
                                                     array(
                                                         array('text'=>'💎 PLANOS 💎',"callback_data"=>'queroservip')//botão com callback                                                                    
                                                      )
                                                          
                                            )
                                    )));       

}  

	
?>